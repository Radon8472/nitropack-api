<?php
namespace NitroPack\SDK\StorageDriver;

use \NitroPack\SDK\FileHandle;

class DiskFileHandle extends FileHandle {}
