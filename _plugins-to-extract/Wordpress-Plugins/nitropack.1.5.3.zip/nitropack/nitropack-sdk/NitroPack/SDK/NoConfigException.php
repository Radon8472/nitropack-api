<?php
namespace NitroPack\SDK;

class NoConfigException extends \Exception {}
