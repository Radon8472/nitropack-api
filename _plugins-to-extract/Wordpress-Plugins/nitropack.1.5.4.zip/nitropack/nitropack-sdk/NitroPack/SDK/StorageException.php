<?php
namespace NitroPack\SDK;

class StorageException extends \RuntimeException {}
