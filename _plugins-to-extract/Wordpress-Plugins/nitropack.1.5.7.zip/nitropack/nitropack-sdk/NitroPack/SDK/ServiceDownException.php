<?php
namespace NitroPack\SDK;

class ServiceDownException extends \RuntimeException {}
