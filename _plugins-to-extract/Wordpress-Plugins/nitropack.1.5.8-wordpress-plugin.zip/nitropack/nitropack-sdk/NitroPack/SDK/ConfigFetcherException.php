<?php
namespace NitroPack\SDK;

class ConfigFetcherException extends \Exception {}
